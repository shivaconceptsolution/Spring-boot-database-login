package uao;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import dao.EmployeeDAO;
import scs.welcomespring.Employee;
import bao.Employees;

import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;;

@ComponentScan(basePackages="dao")
@EnableAutoConfiguration
@RestController
@RequestMapping(path = "/employees")
public class EmployeeController {
	@Autowired
	private EmployeeDAO employeeDAO;
	@GetMapping(
	        path = "/",
	        produces = "application/json")
	 public Employees getEmployees()
	    {
	  
	        return employeeDAO.getAllEmployees();
	    }
	 @PostMapping(
		        path = "/",
		        consumes = "application/json",
		        produces = "application/json")
	 public ResponseEntity<Object> addEmployee(
		        @RequestBody Employee employee)
		    {
		

     employeeDAO
         .addEmployee(employee);

     URI location
         = ServletUriComponentsBuilder
               .fromCurrentRequest()
               .path("/{id}")
               .buildAndExpand(
                   employee.getEmpid())
               .toUri();

            return ResponseEntity
         .created(location)
         .build();
		    }
	 @PostMapping(
		        path = "/login",
		        consumes = "application/json",
		        produces = "application/json")
	 public ResponseEntity<Object> loginEmployee(
		        @RequestBody Employee employee)
		    {
		
        List<Employee> e= employeeDAO.loginEmployee(employee);
       
        String msg="";
        
        if(e.size()>0)
        {
        	msg= "login successfully";
        }
        else
        {
        	msg = "login failed";
        }
       

        Map<String,String> entities = new HashMap<String,String>();
        entities.put("res",msg);
        return new ResponseEntity<Object>(entities, HttpStatus.OK);
		    }
		    
}
