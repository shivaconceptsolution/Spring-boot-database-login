package uao;

import org.springframework.boot.SpringApplication;

public class EmpMain {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeController.class, args);

	}

}
