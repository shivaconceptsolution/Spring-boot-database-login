package dao;
import java.util.Iterator;
import java.util.List;
import org.hibernate.cfg.*;
import org.hibernate.*;
import org.springframework.stereotype.Repository;
import bao.Employees;
import scs.welcomespring.Employee;
import helper.*;
@Repository
public class EmployeeDAO {
	 private static Employees list= new Employees();
	 static
	 {
		   
	     // Creating a few employees
	     // and adding them to the list
	   /*  list.getEmployeeList().add(
	         new Employee(
	             1,
	             "Prem",
	             "Cleark"
	            ));

	     list.getEmployeeList().add(
	         new Employee(
	             2, "Vikash",
	             "Manager"));

	     list.getEmployeeList().add(
	         new Employee(
	             3, "Ritesh",
	             "Developer"
	            ));*/
		    
			
	        
	 }
	 public Employees getAllEmployees()
	 {
		/* Configuration cfg = new Configuration();
			cfg.configure("hibernate.cfg.xml");
			SessionFactory sf = cfg.buildSessionFactory();
			Session s = sf.openSession();
			Query q = s.createQuery("from Employee e");*/
		    Hiberhelper.configure();
		    List lst =   Hiberhelper.selectRecord("from Employee e");
			Iterator it = lst.iterator();
			while(it.hasNext())
			{
				
				Employee emp =(Employee) it.next();
				list.getEmployeeList().add(emp);
			}
			Hiberhelper.closeConn();
	        return list;
	 }
	 public void addEmployee(Employee employee)
      {
		  /*  Configuration cfg = new Configuration();
			cfg.configure("hibernate.cfg.xml");
			SessionFactory sf = cfg.buildSessionFactory();
			Session s = sf.openSession();
			Transaction tx = s.beginTransaction();*/
		    Hiberhelper.configure();
			Employee obj = new Employee();
			obj.setEmpid(employee.getEmpid());
			obj.setEmpname(employee.getEmpname());
			obj.setJob(employee.getJob());
			Hiberhelper.insertUpdateRecord(obj);
			Hiberhelper.closeConn();
			//s.save(obj);
			//tx.commit();
			//s.close();
			
           
      }
	 public List<Employee> loginEmployee(Employee employee)
     {
		  
		    Hiberhelper.configure();
			Query q = Hiberhelper.checkLogin("from scs.welcomespring.Employee e where e.empid=:a and e.empname=:b");
			q.setInteger("a",employee.getEmpid());
			q.setString("b",employee.getEmpname());
			
			return q.list();
			
			//s.save(obj);
			//tx.commit();
			//s.close();
			
          
     }
	
	 
}
