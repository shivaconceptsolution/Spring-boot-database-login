package scs.welcomespring;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@EnableAutoConfiguration
public class SIController {
	@RequestMapping("/si")
	@ResponseBody
	public String calcSi()
	{
		float p=12000,r=2.2F,t=3;
		return "Result is "+(p*r*t)/100;
	}
	

}
